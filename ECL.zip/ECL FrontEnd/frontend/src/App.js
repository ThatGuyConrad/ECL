import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css'
import SelectGroup from './SelectGroup'
import Navbar from 'react-bootstrap/Navbar';

function App() {
  return (
    <div>
    <Navbar expand="lg" bg="dark" variant="dark"><Navbar.Brand>ECL Demo application</Navbar.Brand></Navbar>
    <SelectGroup />
    </div>
  )
}
export default App;
