import React from 'react';
import './users.css'
import 'bootstrap/dist/css/bootstrap.min.css'
import Card from 'react-bootstrap/Card';
import Collapsible from 'react-collapsible';

class Users extends React.Component {
  
    constructor(props) {
        super(props);
        this.state = {
          error: null,
          isLoaded: false,
          items: []
        };
    }

    componentDidMount() {
      //Changing the fetch based on local host or tethered for demo
        //fetch(`http://192.168.43.72:9000/api/users/group/${this.props.name}`)
        fetch(`http://localhost:9000/api/users/group/${this.props.name}`)
        .then(res => res.json())
        .then(
            (result) => {
              this.setState({
                isLoaded: true,
                items: result
              });
            },
            // Note: it's important to handle errors here
            // instead of a catch() block so that we don't swallow
            // exceptions from actual bugs in components.
            (error) => {
              this.setState({
                isLoaded: true,
                error
              });
            }
        )
      }


  render() {
    const { error, isLoaded, items } = this.state;
    if (error) {
      return <div>Error: {error.message}</div>;
    } else if (!isLoaded) {
      return <div>Loading...</div>;
    } else {
        const userCards = Object.keys(items).map(function(key) {
            return <Card key={items[key].externalid}><Card.Body>{items[key].firstname} {items[key].lastname} ID: {items[key].externalid} Phone: {items[key].phone1}</Card.Body></Card>
        });
        return(
            <Collapsible trigger={this.props.name}>
            {userCards}
            </Collapsible>
        )
    }
  }
}

export default Users