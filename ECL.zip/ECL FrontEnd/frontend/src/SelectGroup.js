import React from 'react';
import Select from 'react-select'
import Users from './users'

const ECLgroups = [
    {
        "name":"ECL-All",
        "groups":[
            "DERC",
            "DOC-BMOT",
            "DOC-CSS",
            "DOC-CUR",
            "DOC-FAC",
            "DOC-FIN",
            "DOC-ITS",
            "ESS",
            "ICE",
            "IMT-All",
            "IMT-AOCs",
            "IMT-BMOT",
            "IMT-MAOC",
            "JIC-COM"
        ]
    },
    {
        "name":"ECL-DOC",
        "groups":[
            "DOC-BMOT",
            "DOC-CSS",
            "DOC-CUR",
            "DOC-FAC",
            "DOC-FIN",
            "DOC-ITS"
        ]
    },
    {
        "name":"ECL-IMT",
        "groups":[
            "IMT-All",
            "IMT-AOCs",
            "IMT-BMOT",
            "IMT-MAOC"
        ]
    },
    {
        "name":"ECL-Others",
        "groups":[
            "DERC",
            "ESS",
            "ICE",
            "JIC-COM"
        ]
    }
  ]

let usersList = <p>Please make a selection</p>

class SelectGroup extends React.Component {
    
    state = {
        selectedOption: null,
      };
      handleChange = selectedOption => {
        this.setState({ selectedOption });
        let groups = []
        for(let key in ECLgroups) if(ECLgroups[key].name === selectedOption.value) groups = ECLgroups[key].groups
        usersList = Object.keys(groups).map(function(key) {
            return <Users name={groups[key]} />
        });
      };

    render() {
        
        const { selectedOption } = this.state;
        let eclNames = []
        for(let key in ECLgroups){
            eclNames[key] = {
                'value' : ECLgroups[key].name,
                'label' : ECLgroups[key].name
            }
        }
        return (
            <div>
            <Select value={selectedOption} onChange={this.handleChange} options={eclNames} />
            {usersList}
            </div>
        )
    }
}

export default SelectGroup