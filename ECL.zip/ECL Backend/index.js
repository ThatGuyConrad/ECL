const express = require('express')
const app = express()
const helmet = require('helmet')
const users = require('./routes/users')
const eclgroups = require('./routes/eclgroups')

app.use(express.json())
app.use(helmet())
app.use('/api/eclgroups', eclgroups)
app.use('/api/users', users)

const port = process.env.PORT || 9000
app.listen(port, () => console.log(`Listening on port ${port}...`))