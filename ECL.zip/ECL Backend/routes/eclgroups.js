const express = require('express')
const router = express.Router()

selectedECL = null
const ECLgroups = [
    {
        "name":"ECL-All",
        "groups":[
            "DERC",
            "DOC-BMOT",
            "DOC-CSS",
            "DOC-CUR",
            "DOC-FAC",
            "DOC-FIN",
            "DOC-ITS",
            "ESS",
            "ICE",
            "IMT-All",
            "IMT-AOCs",
            "IMT-BMOT",
            "IMT-MAOC",
            "JIC-COM"
        ]
    },
    {
        "name":"ECL-DOC",
        "groups":[
            "DOC-BMOT",
            "DOC-CSS",
            "DOC-CUR",
            "DOC-FAC",
            "DOC-FIN",
            "DOC-ITS"
        ]
    },
    {
        "name":"ECL-IMT",
        "groups":[
            "IMT-All",
            "IMT-AOCs",
            "IMT-BMOT",
            "IMT-MAOC"
        ]
    },
    {
        "name":"ECL-Others",
        "groups":[
            "DERC",
            "ESS",
            "ICE",
            "JIC-COM"
        ]
    }
]

router.get('/', (req,res) => {
    res.send(ECLgroups);
})

router.get('/:id', (req, res) => {
    for(let i in ECLgroups){
        if(ECLgroups[i]["name"] === req.params.id){
            selectedECL = ECLgroups[i]
            return res.send(selectedECL.groups)
        }
    }
    res.status(400).send('Specified group was not found')
})

module.exports = router