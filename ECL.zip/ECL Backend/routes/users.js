const express = require('express')
const router = express.Router()
const multer = require('multer')
const fs = require('fs')
const csvToJson = require("convert-csv-to-json")
const upload = multer({ dest: 'tmp/csv/' })
const cors = require('cors')

usersJson = []

//get a list of users by group ID
router.get('/group/:id', cors(), (req, res) => {
    var matchingUsers = []
    for(let j in usersJson) 
        if(usersJson[j]["groups"].includes(req.params.id)) matchingUsers.push(usersJson[j])
    res.send(matchingUsers)
})

router.post('/csv', upload.single('file'), (req, res) => {
    
    usersJson = csvToJson.fieldDelimiter(',').getJsonFromCsv(req.file.path);
    //fs.unlinkSync(req.file.path);
    seperateGroups(usersJson)

    res.send(usersJson)
})

function seperateGroups(usersJson){
    for(let j in usersJson){
        usersJson[j]["groups"] = usersJson[j]["groups"].split('|')
    }
}

module.exports = router